			</div>
		</div>		
		<div id="footer">
			<p><strong><em>Fata Morgana</em></strong> ist ein Fan-Projekt für das Survival-Browsergame <a href="http://www.dieverdammten.de/" target="_new">Die Verdammten</a>. Fehler, Anregungen &amp; Wünsche rund um <strong><em>Fata Morgana</em></strong> bitte im <a href="https://docs.google.com/spreadsheet/embeddedform?formkey=dHZNS0xUYXlVQUlKdHdXX2l1Q1JMUUE6MQ" target="_new">eigens eingerichteten Bugtracker</a> eintragen.<br/>
Alle Angaben auf dieser Seite sind ohne Gewähr auf Richtigkeit und/oder Vollständigkeit.
Die verwendeten Icons entstammen dem Browserspiel Die Verdammten selbst und sind somit Eigentum von Motion Twin.</p>
		</div>
		<div id="dynascript"></div> 
		<div id="debug" class="hideme"><pre><?=var_export($debug,true)?></pre></div>
	</body>
</html>

<?php /*<iframe src="https://docs.google.com/spreadsheet/embeddedform?formkey=dHZNS0xUYXlVQUlKdHdXX2l1Q1JMUUE6MQ" width="760" height="913" frameborder="0" marginheight="0" marginwidth="0">Loading...</iframe> 

https://docs.google.com/spreadsheet/ccc?key=0Agti61tNcJHwdHZNS0xUYXlVQUlKdHdXX2l1Q1JMUUE&hl=de_DE#gid=0*/ ?>