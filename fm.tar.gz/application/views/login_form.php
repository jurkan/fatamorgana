<div id="login_form">
	<h1>Ich sehe Dich nur vage, wer bist Du?</h1>
	<?php
		/*echo form_open('login/validate');
		echo form_input('user_name', 'In-game nick');
		echo form_input('user_okey', 'External ID');
		echo form_input('user_skey', 'Secure Oval Office ID');
		echo form_submit('submit', 'Login');*/
		echo anchor('http://www.dieverdammten.de?ref=SinSniper', 'Bürger bei dieVerdammten.de werden');
	?>
	<p style="clear:both;text-align:right;color:#333;">Um Zugriff auf die Fata Morgana zu erhalten, benutze bitte das Seitenverzeichnis direkt im Spiel. </p>
</div>